package com.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Doctor;
import com.service.DoctorService;


@RestController
@RequestMapping("/doctor")
public class DoctorController {
	
	@Autowired
	DoctorService doctorService;

	@GetMapping
	public ResponseEntity<List<Doctor>> getAllDoctorDetail() {
		List<Doctor> doctor = doctorService.getAllDoctorDetail();
		return new ResponseEntity<List<Doctor>>(doctor, HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Doctor> getDoctorById(@PathVariable("id") Integer id) {
		Doctor entity = doctorService.getDoctorById(id);

		return new ResponseEntity<Doctor>(entity, HttpStatus.OK);
	}

	@PostMapping
	public ResponseEntity<Doctor> createOrUpdateStudent(@Valid @RequestBody Doctor doctor) {
		Doctor updated = doctorService.createOrUpdateDoctor(doctor);
		return new ResponseEntity<Doctor>(updated, HttpStatus.OK);
	}

	@DeleteMapping("{id}")
	public HttpStatus deleteStudentById(@PathVariable("id") Integer id) {
		doctorService.deleteDoctorById(id);
	
		return HttpStatus.OK; // 	return HttpStatus.FORBIDDEN-> can be added as per security policies to instruct while delete
	}

}
