package com.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Department;
import com.service.DepartmentService;



@RestController
@RequestMapping("/department")
public class DepartmentController {
	
	
	@Autowired
	DepartmentService departmentService;

	@GetMapping
	public ResponseEntity<List<Department>> getAllDeptDetail() {
		List<Department> dept = departmentService.getAllDeptDetail();
		return new ResponseEntity<List<Department>>(dept, HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Department> getDoctorById(@PathVariable("id") Integer id) {
		Department entity = departmentService.getDeptById(id);

		return new ResponseEntity<Department>(entity, HttpStatus.OK);
	}

	@PostMapping
	public ResponseEntity<Department> createOrUpdateStudent(@Valid @RequestBody Department dept) {
		Department updated = departmentService.createOrUpdateDept(dept);
		return new ResponseEntity<Department>(updated, HttpStatus.OK);
	}

	@DeleteMapping("{id}")
	public HttpStatus deleteDeptById(@PathVariable("id") Integer id) {
		departmentService.deleteDeptById(id);
	
		return HttpStatus.OK; // 	return HttpStatus.FORBIDDEN-> can be added as per security policies to instruct while delete
	}


}
