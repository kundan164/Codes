package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="doctor")
public class Doctor {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="doctorId")
	private int doctorId;
	@NotNull
	@Column(name="doctorName")
	private String doctorName;
	@NotNull
	@Column(name="specilization")
	private String specilization;
	@NotNull
	@Column(name="experience")
	private int experience;
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getSpecilization() {
		return specilization;
	}
	public void setSpecilization(String specilization) {
		this.specilization = specilization;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public Doctor(int doctorId, String doctorName, String specilization, int experience) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.specilization = specilization;
		this.experience = experience;
	}
	public Doctor() {
	}
	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName + ", specilization=" + specilization
				+ ", experience=" + experience + "]\n";
	}
	
	


}
