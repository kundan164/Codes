package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="department")
public class Department {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="deptID")
	private int deptID;
	@NotNull
	@Column(name="deptName")
	private String deptName;
	@NotNull
	@Column(name="noOfBeds")
	private int noOfBeds;
	@NotNull
	@Column(name="floorNo")
	private int floorNo;
	@NotNull
	@Column(name="avlBed")
	private int avlBed;
	public int getDeptID() {
		return deptID;
	}
	public void setDeptID(int deptID) {
		this.deptID = deptID;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public int getNoOfBeds() {
		return noOfBeds;
	}
	public void setNoOfBeds(int noOfBeds) {
		this.noOfBeds = noOfBeds;
	}
	public int getFloorNo() {
		return floorNo;
	}
	public void setFloorNo(int floorNo) {
		this.floorNo = floorNo;
	}
	public int getAvlBed() {
		return avlBed;
	}
	public void setAvlBed(int avlBed) {
		this.avlBed = avlBed;
	}
	public Department(int deptID, String deptName, int noOfBeds, int floorNo, int avlBed) {
		super();
		this.deptID = deptID;
		this.deptName = deptName;
		this.noOfBeds = noOfBeds;
		this.floorNo = floorNo;
		this.avlBed = avlBed;
	}
	public Department() {
	}
	@Override
	public String toString() {
		return "Department [deptID=" + deptID + ", deptName=" + deptName + ", noOfBeds=" + noOfBeds
				+ ", floorNo=" + floorNo + ", avlBed=" + avlBed + "]\n";
	}


}
