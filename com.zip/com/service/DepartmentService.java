package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Department;
import com.repository.DepartmentRepository;
import com.repository.DoctorRepository;

@Service
public class DepartmentService {
	
	@Autowired
	DepartmentRepository departmentRepo; // loosely coupled process
	
	public List<Department> getAllDeptDetail()
	{
		List<Department> dept=departmentRepo.findAll();
		return dept;
		
	}
	
	public Department getDeptById(Integer id) 
    {
        Optional<Department> dept = departmentRepo.findById(id);
        
            return dept.get(); // returns Student Object
            
        
    }
     
    public Department createOrUpdateDept(Department entity) 
    {
    	    	
    	if(entity.getDeptID()<0)
    	{
    	  Optional<Department> dept = departmentRepo.findById(entity.getDeptID());
        
    	if(dept.isPresent())
        {
    		Department newEntity = dept.get();
            newEntity.setDeptID(entity.getDeptID());
            newEntity.setDeptName(entity.getDeptName());
            newEntity.setAvlBed(entity.getAvlBed());
            newEntity.setFloorNo(entity.getFloorNo());
            newEntity.setNoOfBeds(entity.getNoOfBeds());
 
            newEntity = departmentRepo.save(newEntity);
             
            return newEntity;
        } else {
            entity = departmentRepo.save(entity);
             
            return entity;
        }
    	}
    	
    	else
    	{
    		entity =departmentRepo.save(entity);
    		return entity;
    	}	    
 }
     
    public void deleteDeptById(Integer id) 
    {
        Optional<Department> dept = departmentRepo.findById(id);
         
        if(dept.isPresent())
        {
        	departmentRepo.deleteById(id);
        } 
    }

}
