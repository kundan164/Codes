package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Doctor;
import com.repository.DoctorRepository;


@Service
public class DoctorService {
	
	@Autowired
	DoctorRepository doctorRepo; // loosely coupled process
	
	public List<Doctor> getAllDoctorDetail()
	{
		List<Doctor> doctor=doctorRepo.findAll();
		return doctor;
		
	}
	
	public Doctor getDoctorById(Integer id) 
    {
        Optional<Doctor> doctor = doctorRepo.findById(id);
        
            return doctor.get(); // returns Student Object
            
        
    }
     
    public Doctor createOrUpdateDoctor(Doctor entity) 
    {
    	    	
    	if(entity.getDoctorId()<0)
    	{
    	  Optional<Doctor> doctor = doctorRepo.findById(entity.getDoctorId());
        
    	if(doctor.isPresent())
        {
    		Doctor newEntity = doctor.get();
            newEntity.setDoctorId(entity.getDoctorId());
            newEntity.setDoctorName(entity.getDoctorName());
            newEntity.setSpecilization(entity.getSpecilization());
            newEntity.setExperience(entity.getExperience());
           
 
            newEntity = doctorRepo.save(newEntity);
             
            return newEntity;
        } else {
            entity = doctorRepo.save(entity);
             
            return entity;
        }
    	}
    	
    	else
    	{
    		entity =doctorRepo.save(entity);
    		return entity;
    	}	    
 }
     
    public void deleteDoctorById(Integer id) 
    {
        Optional<Doctor> patient = doctorRepo.findById(id);
         
        if(patient.isPresent())
        {
        	doctorRepo.deleteById(id);
        } 
    }

}
