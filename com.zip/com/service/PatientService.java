package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Patient;
import com.repository.PatientRepository;


@Service
public class PatientService {
	
	@Autowired
	PatientRepository patientRepo; // loosely coupled process
	
	public List<Patient> getAllPatientDetail()
	{
		List<Patient> patient=patientRepo.findAll();
		return patient;
		
	}
	
	public Patient getPatientById(Integer id) 
    {
        Optional<Patient> patient = patientRepo.findById(id);
        
            return patient.get(); // returns Student Object
            
        
    }
     
    public Patient createOrUpdatePatient(Patient entity) 
    {
    	    	
    	if(entity.getPatientId()<0)
    	{
    	  Optional<Patient> patient = patientRepo.findById(entity.getPatientId());
        
    	if(patient.isPresent())
        {
    		Patient newEntity = patient.get();
            newEntity.setPatientId(entity.getPatientId());
            newEntity.setPatientName(entity.getPatientName());;
            newEntity.setDisease(entity.getDisease());
 
            newEntity = patientRepo.save(newEntity);
             
            return newEntity;
        } else {
            entity = patientRepo.save(entity);
             
            return entity;
        }
    	}
    	
    	else
    	{
    		entity =patientRepo.save(entity);
    		return entity;
    	}	    
 }
     
    public void deleteStudentById(Integer id) 
    {
        Optional<Patient> patient = patientRepo.findById(id);
         
        if(patient.isPresent())
        {
        	patientRepo.deleteById(id);
        } 
    }

}
